insert into user values (1, now(), 'modise@gmail.com', 'Modise User', 'Last Test', 'password','modise');
insert into user values (2, now(), 'test@gmail.com', 'Test', 'Last', 'password','test');
insert into user values (3, now(), 'kabo@gmail.com', 'Kabo', 'Last', 'password','kabo');
--insert into photo values (1, now(), 'Myself','4oS_2Pa6.jpeg',0,'Myself','Myself',2);
--insert into photo values (2, now(), 'test','cmncsoHs.jpeg',0,'test','test',2)