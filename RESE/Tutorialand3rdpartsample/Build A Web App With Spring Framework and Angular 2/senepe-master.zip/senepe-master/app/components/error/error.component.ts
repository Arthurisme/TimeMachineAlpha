import { Component } from '@angular/core';

/**
 * @author Morebodi Modise
 * @contacts http://github.com/mrmodise, http://mrmodise.com
 */
@Component({
    selector: 'error',
    templateUrl: 'app/components/error/error.component.html'
})
export class ErrorComponent {

}