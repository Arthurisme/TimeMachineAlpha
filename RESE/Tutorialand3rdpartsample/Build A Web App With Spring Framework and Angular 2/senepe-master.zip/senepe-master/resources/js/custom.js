$(document).ready(function(){
    $('#testing').click(function(){
        $(this).hide();
    });
});